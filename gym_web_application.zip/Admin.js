
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault();
    
    

    // Admin credentials (You can change these)
    const adminUsername = "ADMIN";
    const adminPassword = "SAN2108";

    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    let errorMsg = document.getElementById("error-msg");

    if (username === adminUsername && password === adminPassword) {
        errorMsg.textContent = "";
        alert("Login Successful!");
        window.location.href = "https://console.firebase.google.com/project/gym-fitness-78e0e/database/gym-fitness-78e0e-default-rtdb/data/";  // Redirect to Admin Dashboard
    } else {
        errorMsg.textContent = "Invalid Username or Password!";
    }
});
