function checkGymStatus() {
    const now = new Date();
    const day = now.getDay(); // 0 = Sunday, 6 = Saturday
    const hours = now.getHours();
    const minutes = now.getMinutes();

    let isOpen = false;

    if (day >= 1 && day <= 5) { // Monday - Friday
        if ((hours >= 5 && hours < 10) || (hours >= 12 && hours < 16) || (hours >= 18 && hours < 22)) {
            isOpen = true;
        }
    } else if (day === 6) { // Saturday
        if ((hours >= 6 && hours < 11) || (hours >= 13 && hours < 17) || (hours >= 18 && hours < 21)) {
            isOpen = true;
        }
    } else if (day === 0) { // Sunday
        if ((hours >= 8 && hours < 12) || (hours >= 15 && hours < 18)) {
            isOpen = true;
        }
    }

    document.getElementById("gymStatus").textContent = isOpen ? "We are OPEN!" : "Sorry, we are CLOSED.";
}

checkGymStatus();
setInterval(checkGymStatus, 60000); // Update every minute