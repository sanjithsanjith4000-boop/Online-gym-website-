document.addEventListener("DOMContentLoaded", function () {
    // Logo 360° Continuous Spin
    const logo = document.querySelector(".user");
    let angle = 0;

    function spinLogo() {
        angle = (angle + 1) % 360; // Keeps rotating infinitely
        logo.style.transform = `rotateY(${angle}deg)`;
        requestAnimationFrame(spinLogo);
    }

    if (logo) {
        spinLogo();
    }

    // Form Validation
    document.querySelector("form").addEventListener("submit", function (event) {
        const username = document.querySelector("input[name='uname1']").value.trim();
        const email = document.querySelector("input[name='email']").value.trim();
        const age = document.querySelector("input[name='upswd1']").value.trim();
        const height = document.querySelector("input[name='upswd2']").value.trim();
        const weight = document.querySelector("input[name='upswd3']").value.trim();
        const contact = document.querySelector("input[name='upswd5']").value.trim();

        let errorMessage = "";

        if (!username || !email || !age || !height || !weight || !contact) {
            errorMessage = "⚠ Please fill in all required fields.";
        } else if (!/^\S+@\S+\.\S+$/.test(email)) {
            errorMessage = "⚠ Please enter a valid email address.";
        } else if (!/^\d+$/.test(age) || parseInt(age) <= 0) {
            errorMessage = "⚠ Age must be a positive number.";
        } else if (!/^\d+(\.\d+)?$/.test(height)) {
            errorMessage = "⚠ Height must be in a valid format (e.g., 5.8).";
        } else if (!/^\d+(\.\d+)?$/.test(weight)) {
            errorMessage = "⚠ Weight must be in a valid format (e.g., 70.5).";
        } else if (!/^\d{10}$/.test(contact)) {
            errorMessage = "⚠ Contact number must be exactly 10 digits.";
        }

        if (errorMessage) {
            showError(errorMessage);
            event.preventDefault();
        }
    });

    // Function to Display Error Messages
    function showError(message) {
        let errorDiv = document.querySelector(".error-msg");
        if (!errorDiv) {
            errorDiv = document.createElement("div");
            errorDiv.className = "error-msg";
            document.querySelector(".box").appendChild(errorDiv);
        }
        errorDiv.innerHTML = message;
        errorDiv.style.color = "red";
        errorDiv.style.fontWeight = "bold";
        errorDiv.style.marginTop = "10px";
    }
});