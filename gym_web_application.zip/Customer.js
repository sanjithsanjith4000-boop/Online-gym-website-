document.addEventListener("DOMContentLoaded", function () {
    const reviewForm = document.getElementById("review-form");
    const reviewList = document.getElementById("review-list");

    // Function to add a review
    function addReview(name, reviewText) {
        const reviewDiv = document.createElement("div");
        reviewDiv.classList.add("review");
        reviewDiv.innerHTML = `<strong>${name}</strong><p>${reviewText}</p>`;
        reviewList.appendChild(reviewDiv);
    }

    // Load reviews from local storage
    function loadReviews() {
        const reviews = JSON.parse(localStorage.getItem("reviews")) || [];
        reviews.forEach(review => addReview(review.name, review.text));
    }

    // Save reviews to local storage
    function saveReview(name, text) {
        const reviews = JSON.parse(localStorage.getItem("reviews")) || [];
        reviews.push({ name, text });
        localStorage.setItem("reviews", JSON.stringify(reviews));
    }

    // Handle form submission
    reviewForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const name = document.getElementById("name").value;
        const reviewText = document.getElementById("review").value;

        if (name.trim() !== "" && reviewText.trim() !== "") {
            addReview(name, reviewText);
            saveReview(name, reviewText);
            reviewForm.reset();
        }
    });

    // Load existing reviews on page load
    loadReviews();
});