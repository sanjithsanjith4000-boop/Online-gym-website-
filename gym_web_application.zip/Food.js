function generateMeal() {
    const goal = document.getElementById("goal").value;
    const diet = document.getElementById("diet").value;
    const mealTime = document.getElementById("meal_time").value;
    const mealOutput = document.getElementById("meal-output");

    // Meal data based on goal, diet, and meal time
    const meals = {
        weight_loss: {
            vegetarian: {
                breakfast: ["Oats with Almond Milk", "Banana Smoothie", "Avocado Toast"],
                preWorkout: ["Peanut Butter & Apple", "Greek Yogurt", "Almonds & Dates"],
                lunch: ["Quinoa & Chickpeas", "Vegetable Stir-Fry", "Lentil Soup"],
                postWorkout: ["Protein Shake with Soy Milk", "Chia Pudding", "Hummus with Veggies"],
                dinner: ["Grilled Tofu with Greens", "Mixed Vegetable Soup", "Spinach & Paneer Curry"]
            },
            non_vegetarian: {
                breakfast: ["Scrambled Eggs & Whole Wheat Toast", "Oats with Protein Powder", "Boiled Eggs"],
                preWorkout: ["Chicken Sandwich", "Boiled Egg & Almonds", "Protein Bar"],
                lunch: ["Grilled Chicken Salad", "Salmon with Quinoa", "Turkey Wrap"],
                postWorkout: ["Whey Protein Shake", "Tuna Salad", "Chicken Breast with Sweet Potato"],
                dinner: ["Grilled Fish with Steamed Veggies", "Beef Stir-Fry", "Chicken Soup"]
            }
        },
        muscle_gain: {
            vegetarian: {
                breakfast: ["Protein Pancakes", "Chia Seed Pudding", "Oatmeal with Almond Butter"],
                preWorkout: ["Banana & Peanut Butter", "Nuts & Dried Fruits", "Greek Yogurt & Honey"],
                lunch: ["Lentil Rice Bowl", "Paneer Wrap", "Quinoa & Chickpeas"],
                postWorkout: ["Protein Smoothie", "Soy Milk Shake", "Hummus with Whole Wheat Pita"],
                dinner: ["Tofu Stir-Fry", "Vegetable Curry with Brown Rice", "Spinach & Cottage Cheese"]
            },
            non_vegetarian: {
                breakfast: ["Omelette with Cheese", "Protein Shake & Nuts", "Chicken Sausages"],
                preWorkout: ["Tuna Sandwich", "Egg Whites & Banana", "Chicken Wrap"],
                lunch: ["Steak with Brown Rice", "Grilled Chicken & Pasta", "Salmon with Quinoa"],
                postWorkout: ["Whey Protein Shake", "Chicken Breast & Avocado", "Fish & Sweet Potato"],
                dinner: ["Grilled Turkey", "Beef & Broccoli Stir-Fry", "Chicken & Vegetables"]
            }
        },
        maintenance: {
            vegetarian: {
                breakfast: ["Fruit Smoothie", "Oatmeal with Honey", "Almond Butter Toast"],
                preWorkout: ["Dates & Almonds", "Greek Yogurt & Nuts", "Banana Shake"],
                lunch: ["Vegetable Wrap", "Lentil Rice Bowl", "Paneer Salad"],
                postWorkout: ["Chia Pudding", "Hummus with Veggies", "Protein Bar"],
                dinner: ["Stir-Fried Tofu", "Vegetable Soup", "Dal with Brown Rice"]
            },
            non_vegetarian: {
                breakfast: ["Scrambled Eggs with Avocado", "Chicken Omelette", "Boiled Egg Toast"],
                preWorkout: ["Protein Bar", "Egg Whites & Peanut Butter", "Tuna Sandwich"],
                lunch: ["Grilled Chicken with Rice", "Salmon & Sweet Potato", "Turkey Salad"],
                postWorkout: ["Whey Protein", "Chicken Wrap", "Fish & Quinoa"],
                dinner: ["Grilled Chicken with Veggies", "Fish with Brown Rice", "Beef Stir-Fry"]
            }
        }
    };

    // Get the correct meal from the dataset
    const selectedMeal = meals[goal][diet][mealTime];

    // Select a random meal from the category
    const randomMeal = selectedMeal[Math.floor(Math.random() * selectedMeal.length)];
    mealOutput.textContent = randomMeal;
}