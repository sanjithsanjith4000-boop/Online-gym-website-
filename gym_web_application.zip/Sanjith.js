document.addEventListener("DOMContentLoaded", function () {
    // Mobile Menu Toggle
    const mobileBtn = document.querySelector(".mobile-btn");
    const navMenu = document.querySelector(".menu");

    if (mobileBtn) {
        mobileBtn.addEventListener("click", function () {
            navMenu.classList.toggle("active");
        });
    }

    // Top Logo Spin Animation (Front and Back)
    const logo = document.querySelector(".logo img"); // Selecting the top logo
    let angle = 0;
    let spinDirection = 1; // 1 for forward, -1 for backward

    function spinLogo() {
        angle += spinDirection * 2; // Adjust speed of rotation
        logo.style.transform = `rotateY(${angle}deg)`;

        // Reverse spin direction at 180 degrees
        if (angle >= 180 || angle <= 0) {
            spinDirection *= -1;
        }

        requestAnimationFrame(spinLogo);
    }

    spinLogo();

    // Read More Toggle Function
    function toggleReadMore(buttonClass, contentId) {
        const buttons = document.querySelectorAll(buttonClass);
        buttons.forEach((button, index) => {
            const content = document.getElementById(contentId + (index + 1));
            if (button && content) {
                button.addEventListener("click", function () {
                    if (content.style.display === "none" || content.style.display === "") {
                        content.style.display = "block";
                        button.textContent = "Read Less";
                    } else {
                        content.style.display = "none";
                        button.textContent = "Read More";
                    }
                });
            }
        });
    }

    // Applying toggle function for each trainer
    toggleReadMore(".read-more-button", "moreContent");
    toggleReadMore(".read-more-button2", "moreContent2");
    toggleReadMore(".read-more-button3", "moreContent3");
});