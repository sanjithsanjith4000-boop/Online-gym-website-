// Import Firebase SDK
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getDatabase, ref, push, set } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-database.js";

// Firebase Configuration
// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyDrHvajG3xa4gEnsX41rqnNA5JTkP0NR5I",
  authDomain: "online-gym-website.firebaseapp.com",
  projectId: "online-gym-website",
  storageBucket: "online-gym-website.firebasestorage.app",
  messagingSenderId: "746547797189",
  appId: "1:746547797189:web:b9215086ea9c138dcaa4ac",
  measurementId: "G-HEC1TLNX9S"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);


// Handle Form Submission
document.getElementById("fitnessForm").addEventListener("submit", function (event) {
    event.preventDefault(); // Prevent page reload

    // Get form values
    const username = document.getElementById("uname").value;
    const email = document.getElementById("email").value;
    const age = document.getElementById("age").value;
    const height = document.getElementById("height").value;
    const weight = document.getElementById("weight").value;
    const condition = document.getElementById("condition").value;
    const contact = document.getElementById("contact").value;

    // Store data in Firebase Realtime Database
    const userRef = push(ref(database, "users"));
    set(userRef, {
        username,
        email,
        age,
        height,
        weight,
        condition,
        contact
    })
    .then(() => {
        alert("🎉 Registration Successful!");
        document.getElementById("fitnessForm").reset();
    })
    .catch((error) => {
        console.error("⚠️ Error storing data:", error);
        alert("Error occurred. Check console for details.");
    });
});